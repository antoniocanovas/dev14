Updates
=======

`1.0.1`
-------

**Fix:** Pressing the Enter key on the POS search bar does not add a product.

`1.0.0`
-------

**Init version**
