# Copyright (C) Softhealer Technologies.
# Part of Softhealer Technologies.

from . import pos_product_config
